Name - Vakhin S
Final Accuracy - 99.41%
Data Augmentation Techniques - 
1. Resize
2. RandomCrop
3. RandomHorizontalFlip
4. RandomRotation
5. ColorJitter

ReduceLROnPlateau was used to automatically decrease the learning rate by a factor of 0.5 when validation loss stopped improving.”

Bonus Challenges 1, 2 and 3 were attempted
